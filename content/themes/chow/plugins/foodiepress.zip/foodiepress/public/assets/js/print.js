  var pfHeaderImgUrl = '';
  var pfHeaderTagline = '';
  var pfdisableClickToDel = '0';
  var pfHideImages = '0';
  var pfImageDisplayStyle = 'right';
  var pfDisableEmail = '0';
  var pfDisablePDF = '0';
  var pfDisablePrint = '0';
  var pfCustomCSS = '.rsImg {display:block;}';
(function() {
    var e = document.createElement('script'); e.type="text/javascript";
if('https:' == document.location.protocol) {
js='https://pf-cdn.printfriendly.com/ssl/main.js';
}
else{
js='http://cdn.printfriendly.com/printfriendly.js';
}
    e.src = js;
    document.getElementsByTagName('head')[0].appendChild(e);
})();