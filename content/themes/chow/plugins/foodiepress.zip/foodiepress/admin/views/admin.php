<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package   Plugin_Name
 * @author    Your Name <email@example.com>
 * @license   GPL-2.0+
 * @link      http://example.com
 * @copyright 2013 Your Name or Company Name
 */
?>

<div class="wrap">

	<?php screen_icon(); ?>
	<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>
    <p><?php _e('This is setting page for FoodiePress - WordPress recipe plugin, currently we don\'t have many options :) but we will add them in next updates','foodiepress') ?></p>
    <!-- @TODO: Provide markup for your options page here. -->
    <form method="post" action="options.php"> <?php
    settings_fields( 'foodiepress_option_group' );
    do_settings_sections( 'foodiepress' );
    submit_button();
    ?>
</form>
</div>
